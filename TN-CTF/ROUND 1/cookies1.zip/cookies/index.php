<?php
// Ensure the cookie is set to -1 if it does not exist
if (!isset($_COOKIE['name'])) {
    setcookie('name', '-1', time() + 3600, '/');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = $_POST['input'];
    $valid_terms = [
        "bugbounty", "redteaming", "blueteaming", "networking", "cryptography",
        "socialengineering", "malwareanalysis", "incidentresponse", "penetrationtesting",
        "vulnerabilityassessment", "firewall", "ids", "ips", "honeypot", "phishing",
        "ransomware", "rootkit"
    ];

    if (in_array($input, $valid_terms)) {
        $index = array_search($input, $valid_terms);
        setcookie('name', (string)$index, time() + 3600, '/');
        header('Location: check.php');
        exit();
    } else {
        setcookie('name', '-1', time() + 3600, '/');
        $message = "That doesn’t appear to be a valid cookie. Try entering 'bugbounty' as a term.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cookie Challenge</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Cookie Challenge</h1>
        <form action="index.php" method="post">
            <input type="text" name="input" placeholder="Enter a term">
            <button type="submit">Search</button>
        </form>
        <?php if (isset($message)): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
