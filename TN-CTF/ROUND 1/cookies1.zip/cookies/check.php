<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cookie Challenge - Check</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Cookie Check</h1>
        <?php
        $valid_terms = [
            "bugbounty", "redteaming", "blueteaming", "networking", "cryptography",
            "socialengineering", "malwareanalysis", "incidentresponse", "penetrationtesting",
            "vulnerabilityassessment", "firewall", "ids", "ips", "honeypot", "phishing",
            "ransomware", "rootkit"
        ];

        if (isset($_COOKIE['name'])) {
            $name = $_COOKIE['name'];
            if ($name == '17') { // Correct index for the flag
                echo "<div class='message'>Congratulations! Here is your flag:{example_flag}</div>";
            } elseif (is_numeric($name) && $name >= '0' && $name < '17') {
                $term = $valid_terms[$name];
                echo "<div class='message'>That is a cookie! Not very special though... The term is: $term</div>";
            } else {
                echo "<div class='message'>Keep searching!</div>";
            }
        } else {
            header('Location: index.php');
            exit();
        }
        ?>
        <a href="index.php">Go back</a>
    </div>
</body>
</html>
