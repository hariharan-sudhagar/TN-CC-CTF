<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Directory Traversal CTF Challenge</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        h2 {
            color: #333;
            font-size: 24px;
            margin-top: 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background-color: #f9f9f9;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        pre {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Directory Traversal CTF Challenge</h1>
        <?php
        if (isset($_GET['dir'])) {
            $dir = $_GET['dir'];
            // Sanitize input to prevent directory traversal
            $dir = str_replace(array("..", "/", "\\"), "", $dir);
            // Construct the file path
            $filePath = "uploads/" . $dir;
            // Check if the file exists
            if (file_exists($filePath)) {
                // If it's a directory, list its contents
                if (is_dir($filePath)) {
                    echo "<h2>Contents of " . htmlspecialchars($dir) . ":</h2><ul>";
                    // List directory contents
                    $files = scandir($filePath);
                    foreach ($files as $file) {
                        echo "<li>" . htmlspecialchars($file) . "</li>";
                    }
                    echo "</ul>";
                } else {
                    // If it's a file, display its contents
                    echo "<pre>" . htmlspecialchars(file_get_contents($filePath)) . "</pre>";
                }
            } else {
                // File not found
                echo "<p class='error'>File not found.</p>";
            }
        } else {
            // No directory specified
            echo "<p class='error'>No directory specified.</p>";
        }
        ?>
    </div>
</body>
</html>
