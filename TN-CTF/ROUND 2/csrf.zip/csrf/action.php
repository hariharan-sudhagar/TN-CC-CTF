<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $_SESSION['email'] = $email;  // Store the email in the session
    $message = "Email changed to: $email";
    // Log for debugging
    file_put_contents('debug.log', "POST request received: " . print_r($_POST, true) . "\n", FILE_APPEND);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Email</title>
</head>
<body>
    <h1>Change Email</h1>
    <?php if (isset($message)) echo "<p>$message</p>"; ?>
    <form action="action.php" method="post">
        New Email: <input type="email" name="email" required><br>
        <input type="submit" value="Change Email">
    </form>
    <br>
    <a href="logout.php">Logout</a>
</body>
</html>
