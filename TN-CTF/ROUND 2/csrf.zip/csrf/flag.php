<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

// For debugging, show the current session email
if (isset($_SESSION['email']) && $_SESSION['email'] === 'attacker@example.com') {
    echo "Flag: FLAG{csrf_success}";
} else {
    $currentEmail = isset($_SESSION['email']) ? $_SESSION['email'] : 'undefined';
    echo "Unauthorized access. Current email: " . htmlspecialchars($currentEmail);
}
?>
