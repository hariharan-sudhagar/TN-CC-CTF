<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to the CTF Challenge</h2>
        <a href="login.php"><button>Login</button></a>
        <p><strong> Hint:</strong> The starting point often has full control. @admin.</P>
    </div>
   
</body>
</html>
