<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Admin Panel</h2>
        <p>Congratulations! You've successfully logged in.</p>
        <p>Here is your flag: <strong>flag{successful_login}</strong></p>
        <a href="logout.php"><button>Logout</button></a>
    </div>
</body>
</html>
